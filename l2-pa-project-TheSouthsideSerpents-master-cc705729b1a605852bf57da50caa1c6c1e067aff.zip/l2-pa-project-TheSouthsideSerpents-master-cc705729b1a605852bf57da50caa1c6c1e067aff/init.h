#ifndef INIT_H
#define INIT_H

int line_black, line_white, col_black, col_white;
int old_line, new_line, old_col, new_col;

#endif
