#ifndef RESIGN_H
#define RESIGN_H
void resign_command() {
    std::cout << "resign\n";
}
#endif
