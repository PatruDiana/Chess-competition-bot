#ifndef QUEEN_MOVES_H
#define QUEEN_MOVES_H
#include "../board.h"
#include "rook_moves.h"
#include "bishop_moves.h"

std::vector<MoveDet> get_moves_queen(Piece p) {
    std::vector<MoveDet> mv, aux_mv;
    Rook rk(p.color, p.line, p.col);
    mv = get_moves_rook(rk);
    Bishop bp(p.color, p.line, p.col);
    aux_mv = get_moves_bishop(bp);
    mv.insert(mv.end(), aux_mv.begin(), aux_mv.end());
    for (unsigned int i = 0; i < mv.size(); i++) {
        mv[i].piece = p.type;
    }
    return mv;
}
#endif
