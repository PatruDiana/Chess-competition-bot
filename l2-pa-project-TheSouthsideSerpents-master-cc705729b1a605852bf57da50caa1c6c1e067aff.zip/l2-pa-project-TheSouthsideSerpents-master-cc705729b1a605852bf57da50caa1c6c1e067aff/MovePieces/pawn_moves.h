#ifndef PAWN_MOVES_H
#define PAWN_MOVES_H
#include "../board.h"

std::vector<MoveDet> get_moves_pawn_black(Piece p) {
    std::vector<MoveDet> mv;
    int line = p.line, col = p.col;
    PieceType type = p.type;
    Piece fst_piece = b->getBoardConfig(line - 1, col + 1); // find the piece on diag1
    Piece snd_piece = b->getBoardConfig(line - 1, col - 1); // find the piece on diag2
    Piece front = b->getBoardConfig(line - 1, col);
    Piece snd_front = b->getBoardConfig(line - 2, col);
    // Piece left_en_passant = b->getBoardConfig(line, col - 1);
    // Piece right_en_passant = b->getBoardConfig(line, col + 1);
    if (front.type == NONE) {
        MoveDet move(line, col, line - 1, col, type);
        mv.push_back(move);
    }
    Piece en_pas1 = b->getBoardConfig(line - 2, col - 1);
    Piece en_pas2 = b->getBoardConfig(line - 2, col + 1);
    if (line == 7 && front.type == NONE && snd_front.type == NONE
        && (en_pas1.color == NONE || en_pas1.color == EDGE)
        && (en_pas2.color == NONE || en_pas2.color == EDGE)) {
        MoveDet move(line, col, line - 2, col, type);
        mv.push_back(move);
    }
    if (fst_piece.color == WHITE) {
        MoveDet move(line, col, line - 1, col + 1, type);
        mv.push_back(move);
    }
    if (snd_piece.color == WHITE) {
        MoveDet move(line, col, line - 1, col - 1, type);
        mv.push_back(move);
    }

    // if (left_en_passant.type == PAWN_W && snd_piece.type == NONE && p.line == 4) {
    //     MoveDet move(line, col, line - 1, col - 1, type);
    //     mv.push_back(move);
    // }
    // if (right_en_passant.type == PAWN_W && snd_piece.type == NONE && p.line == 4) {
    //     MoveDet move(line, col, line - 1, col + 1, type);
    //     mv.push_back(move);
    // }
    return mv;
}

std::vector<MoveDet> get_moves_pawn_white(Piece p) {
    std::vector<MoveDet> mv;
    int line = p.line, col = p.col;
    PieceType type = p.type;
    Piece fst_piece = b->getBoardConfig(line + 1, col + 1); // find the piece on diag1
    Piece snd_piece = b->getBoardConfig(line + 1, col - 1); // find the piece on diag2
    Piece front = b->getBoardConfig(line + 1, col);
    Piece snd_front = b->getBoardConfig(line + 2, col);
    // Piece left_en_passant = b->getBoardConfig(line, col - 1);
    // Piece right_en_passant = b->getBoardConfig(line, col + 1);
    if (front.type == NONE) {
        MoveDet move(line, col, line + 1, col, type);
        mv.push_back(move);
    }
    Piece en_pas1 = b->getBoardConfig(line + 2, col - 1);
    Piece en_pas2 = b->getBoardConfig(line + 2, col + 1);
    if (line == 2 && front.type == NONE && snd_front.type == NONE
        && (en_pas1.color == NONE || en_pas1.color == EDGE)
        && (en_pas2.color == NONE || en_pas2.color == EDGE)) {
        MoveDet move(line, col, line + 2, col, type);
        mv.push_back(move);
    }
    if (fst_piece.color == BLACK) {
        MoveDet move(line, col, line + 1, col + 1, type);
        mv.push_back(move);
    }
    if (snd_piece.color == BLACK) {
        MoveDet move(line, col, line + 1, col - 1, type);
        mv.push_back(move);
    }
    // if (left_en_passant.type == PAWN_B && snd_piece.type == NONE && p.line == 5) {
    //     MoveDet move(line, col, line + 1, col - 1, type);
    //     mv.push_back(move);
    // }
    // if (right_en_passant.type == PAWN_B && snd_piece.type == NONE && p.line == 5) {
    //     MoveDet move(line, col, line + 1, col + 1, type);
    //     mv.push_back(move);
    // }
    return mv;
}


#endif
