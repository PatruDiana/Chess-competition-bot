#ifndef ROOK_MOVES_H
#define ROOK_MOVES_H
#include "../board.h"

std::vector<MoveDet> get_basic_rook(Piece p);
std::vector<MoveDet> get_attack_rook(Piece p);
std::vector<MoveDet> get_moves_rook(Piece p) {
    std::vector<MoveDet> mv, aux_mov;
    mv = get_basic_rook(p);
    aux_mov = get_attack_rook(p);
    mv.insert(mv.end(), aux_mov.begin(), aux_mov.end());
    return mv;
}

std::vector<MoveDet> get_basic_rook(Piece p) {
  std::vector<MoveDet> mv;
  int line = p.line, col = p.col;
  PieceType type = p.type;

  // right
  Piece piece = b->getBoardConfig(line, col + 1);
  while (piece.type != EDGE) {
    if (piece.type == NONE) {
      MoveDet move(line, col, line, piece.col, type);
      mv.push_back(move);
    } else {
      break;
    }
    piece = b->getBoardConfig(line, piece.col + 1);
  }

  // left
  piece = b->getBoardConfig(line, col - 1);
  while (piece.type != EDGE) {
    if (piece.type == NONE) {
      MoveDet move(line, col, line, piece.col, type);
      mv.push_back(move);
    } else {
      break;
    }
    piece = b->getBoardConfig(line, piece.col - 1);
  }

  // bottom
  piece = b->getBoardConfig(line + 1, col);
  while (piece.type != EDGE) {
    if (piece.type == NONE) {
      MoveDet move(line, col, piece.line, col, type);
      mv.push_back(move);
    } else {
      break;
    }
    piece = b->getBoardConfig(piece.line + 1, col);
  }
  // up
  piece = b->getBoardConfig(line - 1, col);
  while (piece.type != EDGE) {
    if (piece.type == NONE) {
      MoveDet move(line, col, piece.line, col, type);
      mv.push_back(move);
    } else {
      break;
    }
    piece = b->getBoardConfig(piece.line - 1, col);
  }
  return mv;
}

std::vector<MoveDet> get_attack_rook(Piece p) {
  std::vector<MoveDet> mv;
  int line = p.line, col = p.col;
  PieceType type = p.type;

  // right
  Piece piece = b->getBoardConfig(line, col + 1);
  while (piece.type != EDGE) {
    if (piece.color == p.color) {
      break;
    }
    if (piece.color != p.color && piece.color != NO_COL) {
      MoveDet move(line, col, line, piece.col, type);
      mv.push_back(move);
      break;
    }
    piece = b->getBoardConfig(piece.line, piece.col + 1);
  }

  // left
  piece = b->getBoardConfig(line, col - 1);
  while (piece.type != EDGE) {
    if (piece.color == p.color) {
      break;
    }
    if (piece.color != p.color && piece.color != NO_COL) {
      MoveDet move(line, col, line, piece.col, type);
      mv.push_back(move);
      break;
    }
    piece = b->getBoardConfig(line, piece.col - 1);
  }

  // up
  piece = b->getBoardConfig(line - 1, col);
  while (piece.type != EDGE) {
    if (piece.color == p.color) {
      break;
    }
    if (piece.color != p.color && piece.color != NO_COL) {
      MoveDet move(line, col, piece.line, col, type);
      mv.push_back(move);
      break;
    }
    piece = b->getBoardConfig(piece.line - 1, col);
  }

  // bottom
  piece = b->getBoardConfig(line + 1, col);
  while (piece.type != EDGE) {
    if (piece.color == p.color) {
      break;
    }
    if (piece.color != p.color && piece.color != NO_COL) {
      MoveDet move(line, col, piece.line, col, type);
      mv.push_back(move);
      break;
    }
    piece = b->getBoardConfig(piece.line + 1, col);
  }
  return mv;
}


#endif
